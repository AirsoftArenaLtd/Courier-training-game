import subprocess,os,json,pathlib
root=pathlib.Path('/workspace/c41-customer-interaction');out=pathlib.Path('/tmp/c41-browser-regression-f80f76c4');results=[]
env=os.environ.copy();env.update(QA_BROWSER='/usr/bin/chromium',QA_BASE='http://127.0.0.1:8383',QA_FPS_FLOOR='0')
for suite in ['academy','enterprise','routeday','driving']:
 with (out/(suite+'.log')).open('w') as log:
  try:r=subprocess.run(['node','test/'+suite+'.js'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'suite':suite+'.js','exit':code});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(suite,code,flush=True)
if any(r['exit'] for r in results):raise SystemExit(1)
print("The font fallback issue was independently reproduced in the existing browser; the duplicate Tamil journey is superseded by that proof.",flush=True)
raise SystemExit(0)
