from pathlib import Path
import subprocess,json,concurrent.futures
out=Path('/tmp/c42-node-f3462fc2');root=Path('/workspace/c42-problem-solving');original=json.loads((out/'results.json').read_text());failed=[r['suite'] for r in original if r['exit']];results=[]
for name in failed:
 with (out/(name+'.permitted.log')).open('w') as log:r=subprocess.run(['node','test/'+name],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 results.append(dict(suite=name,exit=r.returncode));print(name,r.returncode,flush=True)
(out/'permitted-results.json').write_text(json.dumps(results,indent=2)+'\n');updated={r['suite']:r for r in results};final=[updated.get(r['suite'],r) for r in original];(out/'final-results.json').write_text(json.dumps(final,indent=2)+'\n');raise SystemExit(1 if any(r['exit'] for r in final) else 0)
