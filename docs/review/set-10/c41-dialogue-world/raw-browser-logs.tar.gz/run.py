import subprocess,os,json,pathlib
root=pathlib.Path('/workspace/c41-customer-interaction');out=pathlib.Path('/tmp/c41-browser-regression-075acd92');results=[]
env=os.environ.copy();env.update(QA_BROWSER='/usr/bin/chromium',QA_BASE='http://127.0.0.1:8383',QA_FPS_FLOOR='0')
for suite in ['academy','enterprise','routeday','driving']:
 with (out/(suite+'.log')).open('w') as log:
  try:r=subprocess.run(['node','test/'+suite+'.js'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'suite':suite+'.js','exit':code});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(suite,code,flush=True)
raise SystemExit(0 if all(r['exit']==0 for r in results) else 1)
